import React from "react";
import "./style.scss";
export class Userpage extends React.Component{
    constructor(props){
        super(props);
    }
}