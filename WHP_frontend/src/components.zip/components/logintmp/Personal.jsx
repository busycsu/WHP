import React from "react";
import {useParams} from 'react-router-dom';

export class Personal extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return <div style={{backgroundColor:"#ffffff"}}>
            
        </div>
    }
}

export default Personal;